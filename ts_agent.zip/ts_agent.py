import os
import requests
from getpass import getpass

from langchain_core.prompts import PromptTemplate
from langchain_community.llms import openai
os.environ["OPENAI_API_KEY"] = "sk-WHRCoUdd39GWq4RW084f16CeBaAc4f21BdD178F6Ba55Fd80"

langchain_template = """
You are an expert TypeScript developer. Write TypeScript code based on the following request:

{request}
"""

langchain_prompt = PromptTemplate(
    template=langchain_template, input_variables=["request"]
)

langchain_llm = openai(model_name="text-davinci-003", temperature=0)


langchain_chain = LLMChain(llm=langchain_llm, prompt=langchain_prompt)


def generate_typescript_code_with_langchain(request):
    response = langchain_chain.run({"request": request})
    return response

def generate_typescript_with_ollama(prompt):
    url = "http://localhost:11434"
    payload = {
        "model": "text-davinci-003",
        "prompt": prompt
    }
    response = requests.post(url, json=payload)
    return response.json()["choices"][0]["text"]

def generate_typescript_code_with_ollama(request):
    prompt = f"""
    You are an expert TypeScript developer. Write TypeScript code based on the following request:

    {request}
    """
    return generate_typescript_with_ollama(prompt)

    # stream = ollama.chat(
    #     model='llama3',
    #     messages=[{'role': 'user', 'content': 'Why is the sky blue?'}],
    #     stream=True,
    # )

    # for chunk in stream:
    # print(chunk['message']['content'], end='', flush=True)
request_text = "Create a simple TypeScript function to add two numbers"
typescript_code_langchain = generate_typescript_code_with_langchain(request_text)
print("LangChain Generated Code:")
print(typescript_code_langchain)

typescript_code_ollama = generate_typescript_code_with_ollama(request_text)
print("Ollama Generated Code:")
print(typescript_code_ollama)