from program import write_and_verify_single_code


def agent(language, requirement):
    return write_and_verify_single_code(language, requirement)

if __name__ == '__main__':
    agent('javascript', '如何实现一个字符串反转的函数')