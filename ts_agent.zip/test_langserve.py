from fastapi import FastAPI
from langserve import add_routes

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser


# 1: create prompt template
# 2: create a model
# 3: create parser
# 4： create a chain


system_template = "Translate the following from English to Chinese: {text}"
prompt_template = ChatPromptTemplate.from_messages(
    [
       'system', system_template,
       'user', '{text}',
    ]
)


model = ChatOpenAI(
    api_key="sk-WHRCoUdd39GWq4RW084f16CeBaAc4f21BdD178F6Ba55Fd80",
    base_url="https://api.xty.app/v1"
)

parser = StrOutputParser()

chain = prompt_template | model | parser

app = FastAPI(
  title="LangChain Server",
  version="1.0",
  description="A simple API server using LangChain's Runnable interfaces",
)
add_routes(app, chain, path='/chain')


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)