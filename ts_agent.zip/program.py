from openai import OpenAI
import os
import re
from termcolor import colored
from tools import test_code
client = OpenAI(
    api_key="sk-WHRCoUdd39GWq4RW084f16CeBaAc4f21BdD178F6Ba55Fd80",
    base_url="https://api.xty.app/v1",
    
)

ALLOWED_LANGUAGE = ['javascript', 'python', 'go']
CODE_FILE_SUFFIX = {
    'javascript': '.js',
    'python': '.py',
    'go': '.go',
}
# os.environ["OPENAI_API_KEY"] = "sk-WHRCoUdd39GWq4RW084f16CeBaAc4f21BdD178F6Ba55Fd80"
# os.environ["OPENAI_API_BASE"] = "https://api.xty.app/v1"

# openai.api_key = os.getenv("OPENAI_API_KEY")
# openai.api_base = os.getenv("OPENAI_API_BASE")


def write_and_verify_single_code(language, requirement, max_try=10):
    # 使用language和requirement组装成prompt, 调用openai的接口生成代码，调用tools/cmd里对应的代码执行函数，
    # 把执行结果交给openai评估是否符合预期，如果不符合，则让其重新生成代码，直到符合为止。
    if language not in ALLOWED_LANGUAGE:
        raise ValueError(f'language must be one of {ALLOWED_LANGUAGE}')
    print(f"Generating {language} code for requirement: {requirement}...")

    def gen_or_adjust_code(old_code, old_case, last_result):
        if last_result is None and old_code == "" and old_case == "":
            print("Generating code ...")
            new_code = write_code(language, requirement)
            # print("code generated: \n", new_code)
            print("Generating test cases ...")
            new_cases = write_test_code(language, requirement, new_code)
            # print("test cases generated: \n", new_cases)
            return new_code, new_cases
        elif 'error' in last_result:
            print("Got error when testing code: \n", last_result["error"])
            print("Adjusting code ...")
            new_code, new_cases = adjust_code(language, requirement, old_code, old_case, last_result)
            return new_code, new_cases
        else:
            return old_code, old_case

    try_time = 0
    code = ""
    case_code = ""
    result = None
    while try_time < max_try:
        print(f"Trying {try_time} time...")
        code, case_code = gen_or_adjust_code(code, case_code, result)
        result = test_code(language, code, case_code)
        try_time += 1
        if 'error' not in result:
            break

    if 'error' in result:
        print("Failed to generate code. there are errors remain: \n", result["error"])
        print("============= Code =============: \n", code)
        print("============= Test cases ============= \n", case_code)
    else:
        print("Code generated and tested successfully: \n", result['result'])
        print("============= Code =============: \n", code)
        print("============= Test cases ============= \n", case_code)

    return {
        "code": code,
        "testcase": case_code,
        "result": result,
    }


def complete_code(language, prompt, stream=False):
    print(colored(f'【ME】:  {prompt}', 'blue'))

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": f"You are senior {language} developer."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=4096,
        stream=stream,
    )

    # for chunk in response:
    #     if chunk.choices[0].delta.content is not None:
    #         print(chunk.choices[0].delta.content, end="")

    if stream:
        content = ''
        print(colored('【AI】:  ', 'green'), end='', flush=True)
        for chunk in response:
            if chunk.choices[0].delta.content is not None:
                content += chunk.choices[0].delta.content
                print(colored(chunk.choices[0].delta.content), end="")

        # for chuck in response:
        #     delta = chuck.choices[0].delta
        #     if delta == {}:
        #         print('\n', end='', flush=True)
        #         break
        #     if 'content' in delta:
        #         content += delta['content']
        #     print(colored(delta['content'], 'green'), end='', flush=True)
    else:
        content = response.choices[0]['message']['content']
        print(colored(content, 'green'))
    code_blocks = extract_code_blocks(content)
    return code_blocks or ['']


def write_code(language, requirement):
    prompt = f"""write a piece of {language} code that satisfies the following requirement.
    your code should be:
    1. able to run successfully and output the correct result.
    2. easy to understand and maintain.
    3. testable, export a module or function that can be called by test cases. but you don't need to write test cases.

    requirement:\n {requirement}"""
    return complete_code(language, prompt, True)[0]


def write_test_code(language, requirement, code):
    prompt = f"""write testcases for the following code which satisfies the requirement.
    The test cases should have the following characteristics:
    - Cover all major functionalities and logic branches.
    - Test cases should be independent and avoid interdependencies between tests.
    - Test cases should be short and easy to understand.
    - Test cases should have good naming and structure.
    - Cover various boundary conditions and exceptional situations.
    - Use sufficient test data.
    - Use assertions to verify the expected results of test cases.
    - don't anwser other words, just return codes.
    requirement: 
    {requirement}
    
    code(file: target_code{CODE_FILE_SUFFIX[language]}):
    ```{language}
     {code}```
    
    don't forget to import the code file in your test file. 
    """
    return complete_code(language, prompt, True)[0]


def extract_code_blocks(markdown_text):
    code_blocks = re.findall(r'```(?:\w+\n)?(.+?)```', markdown_text, re.DOTALL)
    return code_blocks


def adjust_code(language, requirement, code, case_code, result):
    prefix = (f"I have a piece of code in the {language} language that does not pass the provided test case. "
              "I need your help to adjust the code and/or test case based on the given error message."
              "The code, test case,f and error message are provided below. "
              "Please provide the adjusted code and/or test case in separate code blocks,"
              "make sure both the code and test case are complete and runnable, don't miss any code."
              " with a comment on the first line of each block indicating whether it's the adjusted"
              " `code` or `testcase`.")
    prompt = f"""{prefix}

    === requirement ===
    {requirement}
    
    === code ===
    ```{language}
    {code}```
    
    === testcases ===
    ```{language}
    {case_code}```
    
    === error ===
    ```{result['error']}
    ```
    """
    codes = complete_code(language, prompt, True)

    # 从codes中找出code和case_code的代码, 代码的第一行均为注释，含code字眼的为code，testcase字眼的为case_code。
    new_code = code
    new_case = case_code
    for c in codes:
        # 读取第一行代码
        first_line = c.split('\n')[0]
        if 'code' in first_line:
            new_code = c
        elif 'testcase' in first_line:
            new_case = c
    return new_code, new_case

