import platform
import subprocess
import tempfile
import os

env = os.environ.copy()
env['PYTHONIOENCODING'] = 'utf-8'

def install_nodejs():
    if platform.system() == "Linux":
        subprocess.run(["sudo", "apt-get", "update"])
        subprocess.run(["sudo", "apt-get", "install", "-y", "nodejs"])
        subprocess.run(["sudo", "apt-get", "install", "-y", "npm"])
    elif platform.system() == "Darwin":  # macOS
        subprocess.run(["brew", "install", "node"])
    else:
        print("Automatic installation is not supported on this platform.")
        return


def install_go():
    if platform.system() == "Linux":
        subprocess.run(["sudo", "apt-get", "update"])
        subprocess.run(["sudo", "apt-get", "install", "-y", "golang"])
    elif platform.system() == "Darwin":  # macOS
        subprocess.run(["brew", "install", "go"])
    else:
        print("Automatic installation is not supported on this platform.")
        return


def check_nodejs_installed():
    try:
        subprocess.run(
            ["node", "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
        return True
    except subprocess.CalledProcessError:
        return False


def check_go_installed():
    try:
        subprocess.run(
            ["go", "version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
        return True
    except subprocess.CalledProcessError:
        return False


def run_command(command, input_data=None):
    try:
        # 使用subprocess运行命令并捕获输出
        result = subprocess.run(
            command,
            input=input_data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env
        )

        # 如果有错误信息，则返回错误信息，否则返回输出结果
        if result.stderr:
            return {"error": result.stderr}
        else:
            return {"result": result.stdout.strip()}
    except Exception as e:
        return {"error": str(e)}


def run_nodejs_code(code):
    if not check_nodejs_installed():
        print("Node.js is not installed, installing...")
        install_nodejs()
    # 将Node.js代码写入临时文件
    with open("temp.js", "w") as temp_file:
        temp_file.write(code)

    # 使用封装的run_command函数运行Node.js代码
    result = run_command(["node", "temp.js"])

    # 删除临时文件
    subprocess.run(["rm", "temp.js"])

    return result


def run_go_code(code):
    if not check_go_installed():
        print("Go is not installed, installing...")
        install_go()
    # 将Go代码写入临时文件
    with tempfile.NamedTemporaryFile(mode="w", suffix=".go", delete=False) as temp_file:
        temp_file.write(code)
        temp_file_name = temp_file.name

    # 编译Go代码
    compile_result = run_command(
        ["go", "build", "-o", "temp_executable", temp_file_name]
    )

    if "error" in compile_result:
        # 删除临时文件
        os.remove(temp_file_name)
        return compile_result

    # 使用封装的run_command函数运行Go代码
    result = run_command(["./temp_executable"])

    # 删除临时文件和临时可执行文件
    os.remove(temp_file_name)
    os.remove("temp_executable")

    return result


def run_python_code(code):
    # 将Python代码写入临时文件
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as temp_file:
        temp_file.write(code)
        temp_file_name = temp_file.name

    # 使用封装的run_command函数运行Python代码
    result = run_command(["python", temp_file_name])

    # 删除临时文件
    os.remove(temp_file_name)

    return result


def run_code(language, code):
    if language == "javascript":
        return run_nodejs_code(code)
    elif language == "go":
        return run_go_code(code)
    elif language == "python":
        return run_python_code(code)
    else:
        return {"error": "Unsupported language."}


def test_nodejs_code(code, case_code, file_name="target_code"):
    if not check_nodejs_installed():
        print("Node.js is not installed, installing...")
        install_nodejs()
    # 再次检测Node.js是否安装成功，仍然未成则报错
    if not check_nodejs_installed():
        return {"error": "Node.js is not installed. I try to install it but fail."}
    # 将Node.js代码写入文件
    with open(f"{file_name}.js", "w", encoding="utf-8") as code_file:
        code_file.write(code)

    # 将测试代码写入文件
    with open(f"{file_name}.test.js", "w",encoding="utf-8") as test_file:
        test_file.write(case_code)

    # 增加jest.config.js文件
    with open("jest.config.js", "w", encoding="utf-8") as config_file:
        config_file.write(
            "module.exports = { testEnvironment: 'node', testMatch: ['**/*.test.js'] };"
        )

    # 使用subprocess运行jest并捕获输出
    result = subprocess.run(
        ["jest", f"{file_name}.test.js"],
        timeout=300,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        shell=True,
        env=env,
        encoding="utf-8",
    )

    # 删除临时文件
    os.remove(f"{file_name}.js")
    os.remove(f"{file_name}.test.js")
    os.remove("jest.config.js")

    # 检查进程退出状态并返回相应的结果
    if result.returncode == 0:
        return {"result": result.stderr.strip()}
    else:
        return {"error": result.stderr.strip()}


def test_go_code(code, case_code):
    # 将Go代码写入临时文件
    with tempfile.NamedTemporaryFile(mode="w", suffix=".go", delete=False) as temp_file:
        temp_file.write(code)
        temp_file_name = temp_file.name

    # 将测试代码写入临时文件
    with tempfile.NamedTemporaryFile(mode="w", suffix=".go", delete=False) as temp_file:
        temp_file.write(case_code)
        test_file_name = temp_file.name

    # 编译Go代码
    compile_result = run_command(
        ["go", "build", "-o", "temp_executable", temp_file_name]
    )

    if "error" in compile_result:
        # 删除临时文件
        os.remove(temp_file_name)
        os.remove(test_file_name)
        return compile_result

    # 使用封装的run_command函数运行Go代码
    result = run_command(["./temp_executable"])

    # 删除临时文件和临时可执行文件
    os.remove(temp_file_name)
    os.remove(test_file_name)
    os.remove("temp_executable")

    return result


def test_python_code(code, case_code):
    # 将Python代码写入临时文件
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as temp_file:
        temp_file.write(code)
        temp_file_name = temp_file.name

    # 将测试代码写入临时文件
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as temp_file:
        temp_file.write(case_code)
        test_file_name = temp_file.name

    # 使用封装的run_command函数运行Python测试代码
    result = run_command(["python", temp_file_name])

    # 删除临时文件
    os.remove(temp_file_name)
    os.remove(test_file_name)

    return result


def test_code(language, code, case_code):
    if language == "javascript":
        return test_nodejs_code(code, case_code)
    elif language == "go":
        return test_go_code(code, case_code)
    elif language == "python":
        return test_python_code(code, case_code)
    else:
        return {"error": "Unsupported language."}
