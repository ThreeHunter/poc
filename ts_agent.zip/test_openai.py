# import os

# from langchain_openai import OpenAI
# from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
# from langchain_core.output_parsers import StrOutputParser
# from langchain_core.prompts import ChatPromptTemplate

# system_prompt = "Translate the following from English to Chinese: {text}"
# prompt_template = ChatPromptTemplate.from_messages(
#     [('system')]
# )

# model = OpenAI(model_name="text-davinci-003",
#                api_key="sk-WHRCoUdd39GWq4RW084f16CeBaAc4f21BdD178F6Ba55Fd80",
#                base_url="https://api.xty.app/v1"
#                )

# message = [
#     SystemMessage(content="Translate the following from English into Chinese"),
#     HumanMessage(content="Hello, I'm a language model."),
# ]

# result = model.invoke(message)

# paser = StrOutputParser()
# paser.invoke(result)

# chain = model | paser
# chain.invoke(message)

# # AIMessage(content='ciao!', response_metadata={'token_usage': {'completion_tokens': 3, 'prompt_tokens': 20, 'total_tokens': 23}, 'model_name': 'gpt-4', 'system_fingerprint': None, 'finish_reason': 'stop', 'logprobs': None}, id='run-fc5d7c88-9615-48ab-a3c7-425232b562c5-0')


from langserve import RemoteRunnable

remote_chain = RemoteRunnable("http://127.0.0.1:8000/chain/")
response = remote_chain.invoke({"language": "italian", "text": "hi"})
print(response)