# 安装python3.10
sudo apt-get install python3.10

在windows下安装python3.10
https://www.python.org/downloads/release/python-3100/


# 安装依赖
pip install -r requirements.txt

# 运行程序

在命令行中输入

python rag.py

# 程序文件说明：

- translate.py: 翻译应用
- doc_writer.py： 文档编写应用
- doc_writer_lc.py： 文档编写应用langchain版
- rag.py： 智能客服
- agent.py ： 智能体
